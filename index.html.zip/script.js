// script.js
console.log("Gesso Code website loaded successfully.");
